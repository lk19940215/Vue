var express = require('express')
var config = require('./config/index')
var axios = require('axios')
var app = express()

var apiRoutes = express.Router()
var sliderData = require('./data/slider_data')
var discListData = require('./data/discList_data')
var singerListData = require('./data/singer_list')
var songListData = require('./data/song_list')
var singerDetail = require('./data/singer-detail')
var rankTopList = require('./data/top_list')
var Lyric = require('./data/Lyric')
var getMusicList = require('./data/getMusicList')
var getHotKey = require('./data/getHotKey')
var KeyData0 = require('./data/getKeyData0')
var KeyData1 = require('./data/getKeyData1')

apiRoutes.param('id', function(req, res, next, id) {
	next()
})

apiRoutes.get('/data/:id', function(req, res, next) {
	if (req.params.id === 'getDiscList') {
		res.send( discListData )
	} else if (req.params.id === 'getSlider') {
		res.jsonp( sliderData )
	} else if (req.params.id === 'getSongList') {
		res.jsonp( songListData )
	} else if (req.params.id === 'getSingerList') {
		res.jsonp( singerListData )
	} else if (req.params.id === 'getSingerDetail') {
		res.jsonp( singerDetail )
	} else if (req.params.id === 'getLyric') {
		res.json( Lyric )
	} else if (req.params.id === 'getTopList') {
		res.jsonp( rankTopList )
	} else if (req.params.id === 'getMusicList') {
		res.jsonp( getMusicList )
	} else if (req.params.id === 'getHotKey') {
		res.jsonp( getHotKey )
	} else if (req.params.id === 'getKeyData0') {
		res.jsonp( KeyData0 )
	} else if (req.params.id === 'getKeyData1') {
		res.jsonp( KeyData1 )
	}
	next()
})

apiRoutes.get('/data/getDiscList', function(req, res) {
	var url = 'https://c.y.qq.com/splcloud/fcgi-bin/fcg_get_diss_by_tag.fcg'
	
	axios.get(url, {
		headers: {
			referer: 'http://c.y.qq.com',
			host: 'c.y.qq.com'
		},
		params: req.query
	}).then((response) => {
		res.json(response.data)
	}).catch((e) => {
		console.log('err')
	})
})

apiRoutes.get('/data/getLyric', function(req, res) {
	var url = 'https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg'
	
	axios.get(url, {
		headers: {
			referer: 'http://c.y.qq.com',
			host: 'c.y.qq.com'
		},
		params: req.query
	}).then((response) => {
		var ret = response.data
		if (typeof ret === 'string') {
			var reg = /^\w+\(({[^()]+})\)/
			var mathes = ret.match(reg)
			if (mathes) {
				ret = JSON.parse(mathes[1])
			}
		}
		res.json(ret)
	}).catch((e) => {
		console.log('err')
	})
})

apiRoutes.get('/another', function(req, res) {
	res.end('<h1 style="font-size:48px;text-align:center;">success jumping</h1>' )
})

app.use(express.static('./dist'))
app.use('/', express.static('./dist/static'))
app.use('/api', apiRoutes)

var port = process.env.PORT || config.build.port

module.exports = app.listen(port, function (err) {
	if (err) {
		console.log(err)
		return
	}
	console.log('Listening at http://localhost:' + port + '\n')
})

