import jsonp from 'common/js/jsonp'
import { commonParams, options } from './config'

export function getHotKey() {
	var url = 'https://c.y.qq.com/splcloud/fcgi-bin/gethotkey.fcg'
	url = '/api/data/getHotKey'
	
	const data = Object.assign({}, commonParams, {
		platform: 'h5',
		nedNewCode: 1
	})
	
	return jsonp(url, data, options)
}

export function search(query, page, zhida, perpage, flag) {
	var url = 'https://c.y.qq.com/soso/fcgi-bin/search_for_qq_cp'
	url = `/api/data/getKeyData${flag}`
	
	const data = Object.assign({}, commonParams, {
		perpage,
		n: perpage,
		w: query,
		p: page,
		catZhida: zhida ? 1 : 0,
		zhidaqu: 1,
		t: 0,
		flag: 1,
		ie: 'utf-8',
		sem: 1,
		aggr: 0,
		remoteplace: 'txt.mqq.all',
		uid: 0,
		needNewCode: 1,
		plateform: 'h5'
	})
	
	return jsonp(url, data, options)
}
