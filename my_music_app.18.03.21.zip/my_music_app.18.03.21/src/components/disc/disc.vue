<template>
	<transition name="slider">
		<music-list :title="title" :bg-image="bgImage" :songs="songs"></music-list>
	</transition>
</template>

<script type="text/ecmascript-6">
	import { mapGetters } from 'vuex'
	import { ERR_OK } from 'api/config'
	import { getSongList } from 'api/recommend'
	import { createSong } from 'common/js/song'
	import MusicList from 'components/music-list/music-list'
	
	export default {
		data() {
			return {
				songs: []
			}
		},
		computed: {
			title() {
				return this.disc.dissname
			},
			bgImage() {
				return this.disc.imgurl
			},
			...mapGetters([
				'disc'
			])
		},
		created() {
			this._getSongList()
		},
		methods: {
			_getSongList() {
				console.log('有大改动')
				if (!this.disc.dissid) {
					this.$router.push({
						path: '/recommend'
					})
				}
				getSongList(this.disc.dissid).then((res) => {
					if (res.code === ERR_OK) {
						this.songs = this._normalizeSongs(res.songlist)
					}
				})
			},
			_normalizeSongs(list) {
				let ret = []
				list.forEach((musicData, index) => {
					if (musicData.data.songid && musicData.data.albumid) {
						ret.push(createSong(musicData.data, index % 8))
					}
				})
				return ret
			}
		},
		components: {
			MusicList
		}
	}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">
	@import "~common/stylus/variable"
	
	.slider-enter-active,.silder-leave-active
		transition: all 0.5s
	.slider-enter,.slider-leave-to
		transform: translate3d(100%, 0, 0)
</style>