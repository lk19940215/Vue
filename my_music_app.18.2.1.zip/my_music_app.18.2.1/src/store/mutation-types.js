export const SET_SINGER = 'SET_SINGER'
