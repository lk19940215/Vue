const state = {
	singer: {}
}

export default state
